import {Environment} from "./environment.interface";

export  const environment :Environment =  {
    production : false, 
    db_url: 'mongodb+srv://ajay:ajay12345@cluster0.bch61.mongodb.net/myFirstDatabase?retryWrites=true&w=majority',
};