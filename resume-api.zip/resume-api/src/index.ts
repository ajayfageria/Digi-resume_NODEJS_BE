import Server from './server';

const port =  process.env.PORT || 5000;


Server.listen(port);